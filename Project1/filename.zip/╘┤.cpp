
#include "test1.h"
#include <stdio.h>
#include"11/souce/unzip.h"
int main() {

	printf("%d",sumss(1, 4));
	unzFile zipFile = unzOpen("filename.zip");
	unzClose(unzFile());

	return 0;
}